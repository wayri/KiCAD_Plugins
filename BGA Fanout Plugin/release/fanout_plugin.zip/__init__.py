from .fanout_gui_preview import FanOutPlugin

FanOutPlugin().register()
