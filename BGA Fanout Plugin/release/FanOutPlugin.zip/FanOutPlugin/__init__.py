from .fanout_gui import FanOutPlugin

FanOutPlugin().register()
